import java.util.PriorityQueue;
  public class Main {
  public static void main(String[] args) {
  // Create a empty Priority Queue
        PriorityQueue<String> pq1 = new PriorityQueue<String>();  
     // use add() method to add values in the Priority Queue
          pq1.add("George");
          pq1.add("Kim");
          pq1.add("John");
          pq1.add("Blake");
          pq1.add("Kevin");
          pq1.add("Michael");
          System.out.println("First Priority Queue: "+pq1);
          PriorityQueue<String> pq2 = new PriorityQueue<String>();  
          pq2.add("George");
          pq2.add("Katie");
          pq2.add("Kevin");
          pq2.add("Michelle");
          pq1.add("Ryan");
          System.out.println("Second Priority Queue: "+pq2);
          System.out.println("Intersection of two queues");
          //Print intersection of elements in Priority Queue
         for (String element : pq1){
             if((pq2.contains(element)))
             {
                 System.out.println(element);
             };
          }  
          //Print the difference of the two queues.
        System.out.println("Difference of two queues");
         for (String element : pq1){
             if(!(pq2.contains(element)))
             {
                 System.out.println(element);
             };
          } 
        System.out.println("Union of two queues");
         for (String element : pq1){
             if(!(pq2.contains(element)))
             {
                 pq2.add(element);
             };
          } 
        System.out.println(pq2);
     }
}